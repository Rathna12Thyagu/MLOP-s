from flask import Flask,render_template,request

app = Flask(__name__) 
import pickle
classi = pickle.load(open('class.pkl','rb'))

import pymysql as pms
conn = pms.connect(host="localhost",port=3306,user="root",
                   password="jann@123",db="pass")

@app.route("/")#flask does't know where to disp so
def home():
    return  render_template("index.html")

@app.route("/check",methods=['post'])
def check():
    val = [i for i in (request.form.values())]
    uname = val[0]
    passw = val[1]
    cur = conn.cursor()
    c=0
    f=0
    cur.execute("select * from details")
    d = cur.fetchall()
    for i in range(len(d)):
        if(uname in d[i]):
            c=i
            f=0
            break
        else:
            f=1
    if(f==1):
        cur.execute("insert into details (Name,Pass_Word) values(%s,%s)",
                    (uname,passw))
        conn.commit()
        return render_template("index.html",data = "Signup Now!!")

    else:        
        if(passw == d[c][1]):
            return render_template("cl.html")
        else:
            return render_template("index.html",data = "Invalid try again")

@app.route("/classi",methods=['post'])
def classify():
    features = [float(i) for i in (request.form.values())]
    pred = classi.predict([features])
    if(pred[0]==0):
        return "Low chances of getting heart attack"
    else:
         return "high chances of getting heart attack"
    

if __name__ == "__main__":
    app.run()
    