import pandas as pd
import numpy as np
#%%
df = pd.read_csv(r"C:\Users\ponra\Desktop\flask\heart.csv")
print(df.columns)
df.drop(['cp','fbs','restecg','oldpeak','slp','caa','thall','exng'],axis=1,inplace=True)
print(df.columns)
#%%
df.columns = ['Age','Sex','Resting blood pressure (in mm Hg)',
              'cholestoral in mg/dl','maximum heart rate achieved',
              'Output']
#%%
x = df.iloc[:,:-1].values
y = df.iloc[:,-1].values
#%%
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
x = sc.fit_transform(x)
print(x)
#%%
from sklearn.linear_model import LogisticRegression
binary_classification = LogisticRegression()

lg = binary_classification.fit(x,y)

import pickle
pickle.dump(binary_classification,open('class.pkl','wb'))
